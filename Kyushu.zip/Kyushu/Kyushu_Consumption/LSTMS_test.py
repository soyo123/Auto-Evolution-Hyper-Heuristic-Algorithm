import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential 
from tensorflow.keras.layers import LSTM, Dense
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from pyswarm import pso

# 加载数据
file_path = '/mnt/data/training data japan1.csv'
data = pd.read_csv(file_path)

# 清理数据，删除不必要的列并设置日期为索引
data = data.drop(columns=['北海道電力'])
data['date'] = pd.to_datetime(data['date'], format='%Y%m')
data.set_index('date', inplace=True)

# 归一化数据
scaler = MinMaxScaler(feature_range=(0, 1))
scaled_data = scaler.fit_transform(data)

# 创建数据集
def create_dataset(data, look_back=1):
    X, Y = [], []
    for i in range(len(data) - look_back - 1):
        X.append(data[i:(i + look_back), 0])
        Y.append(data[i + look_back, 0])
    return np.array(X), np.array(Y)

look_back = 12
train_size = int(len(scaled_data) * 0.67)
train, test = scaled_data[0:train_size,:], scaled_data[train_size:len(scaled_data),:]
trainX, trainY = create_dataset(train, look_back)
testX, testY = create_dataset(test, look_back)

trainX = np.reshape(trainX, (trainX.shape[0], trainX.shape[1], 1))
testX = np.reshape(testX, (testX.shape[0], testX.shape[1], 1))

# 构建LSTM模型
def create_lstm_model(look_back, learning_rate):
    model = Sequential()
    model.add(LSTM(50, input_shape=(look_back, 1)))
    model.add(Dense(1))
    optimizer = Adam(learning_rate=learning_rate)
    model.compile(loss='mean_squared_error', optimizer=optimizer)
    return model

# PSO优化
def lstm_train_evaluate(lr, data, look_back=1, epochs=50, batch_size=1):
    train_size = int(len(data) * 0.67)
    train, test = data[0:train_size,:], data[train_size:len(data),:]
    trainX, trainY = create_dataset(train, look_back)
    testX, testY = create_dataset(test, look_back)
    
    trainX = np.reshape(trainX, (trainX.shape[0], trainX.shape[1], 1))
    testX = np.reshape(testX, (testX.shape[0], testX.shape[1], 1))
    
    model = create_lstm_model(look_back, lr)
    model.fit(trainX, trainY, epochs=epochs, batch_size=batch_size, verbose=0)
    
    testPredict = model.predict(testX)
    mse = mean_squared_error(testY, testPredict)
    return mse

def optimize_learning_rate(data, look_back=1, epochs=50, batch_size=1):
    lb = [0.0001]
    ub = [0.1]
    args = (data, look_back, epochs, batch_size)
    opt_lr, _ = pso(lstm_train_evaluate, lb, ub, args=args, swarmsize=10, maxiter=10)
    return opt_lr

opt_lr = optimize_learning_rate(scaled_data, look_back)
print('Optimized Learning Rate:', opt_lr)

# 使用优化的学习率训练和评估LSTM模型
model = create_lstm_model(look_back, opt_lr)
model.fit(trainX, trainY, epochs=50, batch_size=1, verbose=2)

trainPredict = model.predict(trainX)
testPredict = model.predict(testX)

trainPredict = scaler.inverse_transform(trainPredict)
trainY = scaler.inverse_transform([trainY])
testPredict = scaler.inverse_transform(testPredict)
testY = scaler.inverse_transform([testY])

trainScore = np.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
testScore = np.sqrt(mean_squared_error(testY[0], testPredict[:,0]))
print('Train Score: %.2f RMSE' % (trainScore))
print('Test Score: %.2f RMSE' % (testScore))
