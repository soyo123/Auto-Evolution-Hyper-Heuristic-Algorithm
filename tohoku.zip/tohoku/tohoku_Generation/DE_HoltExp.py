import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
from statsmodels.tsa.holtwinters import Holt

################# Begin Import the train data1(training data japan1.csv) ##################
with open('training data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
train_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the train data2(actual data)(training data japan2.csv) ##############
with open('training data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
train_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

################# Begin Import the train data3(actual data)(training data japan2.csv) ##############
with open('training data japan3.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
train_japan3 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=2 # Dimension

# Generating the population
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)

############################# Begin HoltExpSmoothing model ##############################
series = train_japan3 #Define the seasonal data list
n_preds=24
# Define the SimpleExpSmoothing model
def HoltExp_model(series, alpha, beta, n_preds):
    def double_exponential_smoothing(series, alpha, beta):
        result = [series[0]]
        trend = [series[1] - series[0]]
        
        for i in range(1, len(series)):
            forecast = alpha * series[i] + (1 - alpha) * (result[i-1] + trend[i-1])
            trend.append(beta * (forecast - result[i-1]) + (1 - beta) * trend[i-1])
            result.append(forecast)
            
        return result
    # 预测
    array_forecast = double_exponential_smoothing(series, alpha, beta)
     # Define the dataset as python lists 
    actual   = train_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
     # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    # return MAPE ,forecast
    return MAPE,forecast
############################# End HoltExpSmoothing model ##############################


################### Begin DE algorithm ###############################
cr=0.5
x = np.random.rand(N, D) * (x_max - x_min) + x_min
def deAlgorithm(cr, x, N, D, n_preds):
    
    nIter=500
    uniRand = np.random.uniform
    def func(series,xs,n_preds):
    # print(x)
        # print(xs)
        alpha=xs[0]
        # print(alpha)
        beta=xs[1]
        m=HoltExp_model(series, alpha, beta, n_preds)
        return m[0]
    
        # N为个体数；nDim为解维度；nIter为迭代次数
    def de(D, cr, func, nIter,x):
        # xs = [uniRand(*xRange, nDim) for _ in range(N)]
        # xs = [x for _ in range(N)]
        # xs = [x[i] for _ in range(N)]
        xs = []
        for i in range(0,len(x)):
            xs.append(x[i])
        # xs = x
        # print(x)
        # sum_of_de = 0
        # number_of_de = 0
        for _ in range(nIter):
            xs = evolve(xs, cr, func)
        fs = [func(series,x,n_preds) for x in xs]
        xBest = xs[np.argmin(fs)]
        msg = f"当前最优结果为{np.min(fs)}，参数为"
        msg += ", ".join([f"{x:.4f}" for x in xBest])
        # sum_of_de += np.min(fs)
        # number_of_de += 1
        # print(msg)
        return np.min(fs),xBest
    
    # if __name__=="__main__":
    #     de(D,cr,func,nIter,x)
    
    def evolve(xs,cr,func):
        # 变异
        vs = []
        N = len(xs[0])
        for _ in range(len(xs)):
            # print(xs)
            x = xs.pop(0)
            r1, r2, r3 = sample(xs, 3)
            xs.append(x)
            vs.append(r1 + random()*(r2-r3))
        # 交叉
        us = []
        for i in range(len(xs)):
            us.append(vs[i] if random() < cr else xs[i])
            j = randint(0, N-1)
            us[i][j] = vs[i][j]
        # 选择（这里选的最小）
        # print(us)
        xNext = []
        for x,u in zip(xs, us):
            xNext.append(x if func(series,x,n_preds)<func(series,u,n_preds) else u)
        return xNext
    
    return de(D, cr, func, nIter,x)

trainvalue = deAlgorithm(cr, x, N, D, n_preds)

#训练集数据储存
trainresults=trainvalue[0]
filename = "TrainResults_DE_HoltExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
#     # for row in data2:
#     #     writer.writerow(float(item) for item in row)
#     writer.writerow([float(item) for item in trainresults])

# # 打开文件以写入模式
# with open('output.csv', 'w', newline='') as file:
#     writer = csv.writer(file)
    
    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(trainresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in trainresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(trainresults)])

############################################# Test Data Set#########################################################

################# Begin Import the test data1(test data japan1.csv) ##################
with open('test data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
test_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the test data2(actual data)(test data japan2.csv) ##############
with open('test data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

################# Begin Import the test data3(actual data)(test data japan3.csv) ##############
with open('test data japan3.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan3 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################


x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=2 # Dimension

# Generating the population
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)

############################# Begin HoltExpSmoothing model ##############################
series = test_japan3 #Define the seasonal data list
n_preds=24
# Define the SimpleExpSmoothing model
def test_HoltExp_model(series, alpha, beta, n_preds):
    def double_exponential_smoothing(series, alpha, beta):
        result = [series[0]]
        trend = [series[1] - series[0]]
        
        for i in range(1, len(series)):
            forecast = alpha * series[i] + (1 - alpha) * (result[i-1] + trend[i-1])
            trend.append(beta * (forecast - result[i-1]) + (1 - beta) * trend[i-1])
            result.append(forecast)
            
        return result
    # 预测
    array_forecast = double_exponential_smoothing(series, alpha, beta)
    # Define the dataset as python lists 
    actual   = test_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
    # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    # return MAPE ,forecast
    return MAPE,forecast
############################# End HoltExpSmoothing model ##############################

Plotvalue = trainvalue[1]
alpha = Plotvalue[0]
beta =  Plotvalue[1]
data1 = test_HoltExp_model(series, alpha, beta, n_preds)

########################################  测试集上的数据储存 ######################################## 
testresults = data1[0]
filename = "TestResults_DE_HoltExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # # for row in data2:
    # #     writer.writerow(float(item) for item in row)
    # writer.writerow([float(item) for item in testresults])

    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(testresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in testresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(testresults)])
########################################  测试集上的预测值数据 ######################################## 

data2 = data1[1]
filename = "DE_HoltExp.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # for row in data2:
    #     writer.writerow(float(item) for item in row)
    writer.writerow([float(item) for item in data2])
print(data2)
print(testresults)