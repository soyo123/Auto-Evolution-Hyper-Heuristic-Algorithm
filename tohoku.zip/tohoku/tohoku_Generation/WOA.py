import numpy as np

# 定义目标函数（可以根据实际问题更改）
def objective_function(x):
    return np.sum(x**2)

# 初始化种群
def initialize_population(pop_size, dim, lower_bound, upper_bound):
    return lower_bound + (upper_bound - lower_bound) * np.random.rand(pop_size, dim)

# 更新位置
def update_position(whales, leader, a, lower_bound, upper_bound):
    pop_size, dim = whales.shape
    for i in range(pop_size):
        r1, r2 = np.random.rand(), np.random.rand()
        A = 2 * a * r1 - a
        C = 2 * r2
        p = np.random.rand()
        
        if p < 0.5:
            if abs(A) < 1:
                D = abs(C * leader - whales[i])
                whales[i] = leader - A * D
            else:
                rand_whale = whales[np.random.randint(pop_size)]
                D = abs(C * rand_whale - whales[i])
                whales[i] = rand_whale - A * D
        else:
            distance_to_leader = abs(leader - whales[i])
            whales[i] = distance_to_leader * np.exp(2 * (-p)) * np.cos(2 * np.pi * p) + leader
        
        # 确保鲸鱼的位置在边界内
        whales[i] = np.clip(whales[i], lower_bound, upper_bound)
    return whales

# 鲸鱼优化算法
def woa(objective_function, pop_size, dim, lower_bound, upper_bound, max_iter):
    # 初始化种群
    whales = initialize_population(pop_size, dim, lower_bound, upper_bound)
    fitness = np.apply_along_axis(objective_function, 1, whales)
    
    # 找到初始的领导者
    leader_idx = np.argmin(fitness)
    leader = whales[leader_idx]
    
    # 主循环
    for iteration in range(max_iter):
        a = 2 - iteration * (2 / max_iter)  # a 从 2 线性递减到 0
        
        # 更新鲸鱼的位置
        whales = update_position(whales, leader, a, lower_bound, upper_bound)
        
        # 计算新种群的适应度
        fitness = np.apply_along_axis(objective_function, 1, whales)
        
        # 更新领导者
        current_leader_idx = np.argmin(fitness)
        current_leader = whales[current_leader_idx]
        if fitness[current_leader_idx] < fitness[leader_idx]:
            leader_idx = current_leader_idx
            leader = current_leader
        
        # 打印当前最佳结果
        print(f"Iteration {iteration + 1}, Best fitness: {fitness[leader_idx]}")
    
    return leader, fitness[leader_idx]

# 参数设置
pop_size = 20
dim = 5
lower_bound = -10
upper_bound = 10
max_iter = 100

# 运行鲸鱼优化算法
best_position, best_fitness = woa(objective_function, pop_size, dim, lower_bound, upper_bound, max_iter)

print(f"Best position: {best_position}")
print(f"Best fitness: {best_fitness}")
