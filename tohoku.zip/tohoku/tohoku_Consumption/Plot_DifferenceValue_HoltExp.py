import numpy as np
from numpy.random import random as rand
import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
import matplotlib.pyplot as plt


################# Begin Import the consumption data ##################
with open('/Users/soyo/Desktop/paper_July 5_6pages/code/journal/tohoku/tohoku_Consumption/forcasting data_HoltExpCon.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
data1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the generation data ##################
with open('/Users/soyo/Desktop/paper_July 5_6pages/code/journal/tohoku/tohoku_Consumption/forcasting data_HoltExpGen.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
data2 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################


################# Begin Import the real consumption data ##################
with open('/Users/soyo/Desktop/paper_July 5_6pages/code/journal/tohoku/tohoku_Consumption/realdata_Con.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
data3 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the real generation data ##################
with open('/Users/soyo/Desktop/paper_July 5_6pages/code/journal/tohoku/tohoku_Consumption/realdata_Gen.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
data4 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

# 计算差值
difference1 = np.array(data1) - np.array(data2) 
difference2 = np.array(data3) - np.array(data4) 

# 创建月份列表
months = [
    'Jan 2014', 'Feb 2014', 'Mar 2014', 'Apr 2014', 'May 2014', 'Jun 2014', 'Jul 2014', 'Aug 2014', 'Sep 2014', 'Oct 2014', 'Nov 2014', 'Dec 2014',
    'Jan 2015', 'Feb 2015', 'Mar 2015', 'Apr 2015', 'May 2015', 'Jun 2015', 'Jul 2015', 'Aug 2015', 'Sep 2015', 'Oct 2015', 'Nov 2015', 'Dec 2015'
]


# 创建x轴刻度
x = np.arange(len(months))

# 设置柱状图的宽度
width = 0.4

# 创建图形
plt.figure(figsize=(14, 7))

# 绘制两组数据的柱状图
plt.bar(x - width/2, difference1, width, label='Forcasting Difference', color='skyblue')
plt.bar(x + width/2, difference2, width, label='Actual Difference', color='lightgreen')

# 添加标签和标题
plt.xlabel('Month')
plt.ylabel('Difference (Electricity Consumption - Renewable Eenergy Generation(MWh))')
plt.title('Tohoku-Difference Between Electricity Consumption And Renewable Eenergy Generation with Double Exponential Smoothing')
plt.xticks(x, months, rotation=45)

# 添加图例
plt.legend()

# 显示网格线
plt.grid(axis='y', linestyle='--', alpha=0.7)

# 调整布局
plt.tight_layout()

plt.savefig("Tohoku_DiffrnenceValue_HoltExp", dpi=750)

# 显示图形
plt.show()