import csv
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib
from random import sample, randint, random
from statsmodels.tsa.holtwinters import Holt
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

################# Begin Import the train data1(training data japan1.csv) ##################
with open('training data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
train_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the train data2(actual data)(training data japan2.csv) ##############
with open('training data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
train_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

################# Begin Import the train data3(actual data)(training data japan2.csv) ##############
with open('training data japan3.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
train_japan3 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=1 # Dimension

# Generating the population
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)

# ############################# Begin WMAExp model ##############################
# series = train_japan3 #Define the seasonal data list
# n_preds=24
# # Define the SimpleExpSmoothing model
# def WMAExp_model(series, alpha):
#     def ewma(new_value, previous_ema, alpha):
#         return alpha * new_value + (1 - alpha) * previous_ema
 
#     # 示例使用
#     # alpha = 1.1  # 平滑因子
#     previous_ema = 0  # 初始化之前的 EMA 值为 0
#     # values = [1, 2, 3, 4, 5]  # 假设有一系列数据
#     values = series
#     ema_list = []
    
#     for value in values:
#         previous_ema = ewma(value, previous_ema, alpha)
#         ema_list.append(previous_ema)

#      # 预测
#     array_forecast = ema_list
#      # Define the dataset as python lists 
#     actual   = train_japan2
#     forecast = array_forecast
#     # Consider a list APE to store the 
#     # APE value for each of the records in dataset 
#     APE = [] 
#      # Iterate over the list values 
#     for day in range(24): 

#         # Calculate percentage error 
#         per_err = (actual[day] - forecast[day]) / actual[day] 

#         # Take absolute value of 
#         # the percentage error (APE) 
#         per_err = abs(per_err) 

#         # Append it to the APE list 
#         APE.append(per_err) 

#     # Calculate the MAPE 
#     MAPE = sum(APE)/len(APE)
#     # Print the MAPE value and percentage 
#     # print(f''' 
#     # MAPE   : { round(MAPE, 2) } 
#     # MAPE % : { round(MAPE*100, 2) } % 
#     # ''')
#     # return MAPE ,forecast
#     return MAPE,forecast
# ############################# End WMAExp model ##############################


############################# Begin LSTM model ##############################
n_preds=24
def LSTM_model(train_japan2,train_japan3, alpha):
    # 假设我们有一些时间序列数据
    # X_train 是输入数据，形状为 (样本数, 时间步长, 特征数)
    # y_train 是目标数据，形状为 (样本数, 输出维度)
    # 这里我们只是创建一些随机数据作为示例
    # X_train = np.random.random((100, 10, 1))  # 100个样本，每个样本10个时间步长，每个时间步长1个特征
    # y_train = np.random.random((100, 1))      # 100个样本，每个样本1个输出值
    X_train = train_japan3 
    y_train = train_japan2

    X_train = np.array(X_train)
    y_train = np.array(y_train)
    X_train= X_train.reshape(-1, 1, 1)
    y_train= y_train.reshape(-1, 1, 1)

    # 定义LSTM模型
    model = Sequential()
    model.add(LSTM(50, activation='relu', input_shape=(1, 1)))  # 输入层，50个LSTM单元
    model.add(Dense(1))  # 输出层，1个输出单元

    # 编译模型
    # learning_rate=0.001
    learning_rate=alpha
    optimizer = tf.keras.optimizers.Adam(learning_rate)
    model.compile(optimizer=optimizer, loss='mse')  # 使用Adam优化器和均方误差损失函数

    # 训练模型
    model.fit(X_train, y_train, epochs=1, batch_size=32, verbose=1)

    # 使用模型进行预测
    # X_test = np.random.random((100, 10, 1))  # 假设我们有一个测试样本

    X_test = train_japan3 

    X_test = np.array(X_test)
    X_test = X_test.reshape(-1, 1, 1)


    y_pred = model.predict(X_test)
    # print(y_pred)

    array_forecast = y_pred
    # print(array_forecast)
        # Define the dataset as python lists 
    actual   = train_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
     # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    return MAPE , forecast
############################# End LSTM model ##############################

x = np.random.rand(N, D) * (x_max - x_min) + x_min
################### Begin WOA algorithm ###############################
def woaAlgorithm(x, N, D, n_preds):
    # 参数设置
    pop_size = 30
    # dim = 5
    # lower_bound = -10
    # upper_bound = 10
    max_iter = 1

    # # 定义目标函数（可以根据实际问题更改）
    # def objective_function(x):
    #     return np.sum(x**2)
    
    def func(x, n_preds):
        # print(x)
        alpha=x[0]
        m1=LSTM_model(train_japan2,train_japan3, alpha)
        return m1[0]

    # # 初始化种群
    # def initialize_population(pop_size, dim, lower_bound, upper_bound):
    #     return lower_bound + (upper_bound - lower_bound) * np.random.rand(pop_size, dim)

    # 更新位置
    def update_position(whales, leader, a):
        pop_size, dim = whales.shape
        for i in range(pop_size):
            r1, r2 = np.random.rand(), np.random.rand()
            A = 2 * a * r1 - a
            C = 2 * r2
            p = np.random.rand()
            
            if p < 0.5:
                if abs(A) < 1:
                    D = abs(C * leader - whales[i])
                    whales[i] = leader - A * D
                else:
                    rand_whale = whales[np.random.randint(pop_size)]
                    D = abs(C * rand_whale - whales[i])
                    whales[i] = rand_whale - A * D
            else:
                distance_to_leader = abs(leader - whales[i])
                whales[i] = distance_to_leader * np.exp(2 * (-p)) * np.cos(2 * np.pi * p) + leader
            
            # 确保鲸鱼的位置在边界内
            # whales[i] = np.clip(whales[i], x_max, x_min)
        return whales

    # 鲸鱼优化算法
    def woa(func, pop_size, D, max_iter, x):
        # 初始化种群
        # whales = initialize_population(pop_size, dim, lower_bound, upper_bound)
        whales = x
        # fitness = np.apply_along_axis(objective_function, 1, whales)
        fitness = np.apply_along_axis(func, 1, whales, n_preds)
        
        # 找到初始的领导者
        leader_idx = np.argmin(fitness)
        leader = whales[leader_idx]
        
        # 主循环
        for iteration in range(max_iter):
            a = 2 - iteration * (2 / max_iter)  # a 从 2 线性递减到 0
            
            # 更新鲸鱼的位置
            whales = update_position(whales, leader, a)
            
            # 计算新种群的适应度
            fitness = np.apply_along_axis(func, 1, whales, n_preds)
            
            # 更新领导者
            current_leader_idx = np.argmin(fitness)
            current_leader = whales[current_leader_idx]
            if fitness[current_leader_idx] < fitness[leader_idx]:
                leader_idx = current_leader_idx
                leader = current_leader
            
            # 打印当前最佳结果
            # print(f"Iteration {iteration + 1}, Best fitness: {fitness[leader_idx]}")
        
        return  fitness[leader_idx],leader
    return woa(func, pop_size, D, max_iter,x)


# 运行鲸鱼优化算法
trainvalue = woaAlgorithm(x, N, D, n_preds)

#训练集数据储存
trainresults=trainvalue[0]
filename = "TrainResults_WOA_LSTM.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)    
    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(trainresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in trainresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(trainresults)])

############################################# Test Data Set#########################################################

################# Begin Import the test data1(test data japan1.csv) ##################
with open('test data japan1.csv', 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    # Skip the title row（if have）
    next(reader)
    # Define the index of columns
    columns_of_interest = [2]  # the index begin from 0
    # Define a list
    str_array = []
    for row in reader:
        selected_data = [row[col] for col in columns_of_interest]  # choose the columns
        # Put the item into the list
        str_array.append(selected_data[0])
# Change the string item of list into float
test_japan1 = [float(s) for s in str_array]
# print(train_japan1)
#####################################END#########################################

################# Begin Import the test data2(actual data)(test data japan2.csv) ##############
with open('test data japan2.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan2 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################

################# Begin Import the test data3(actual data)(test data japan3.csv) ##############
with open('test data japan3.csv', 'r', newline='') as csvfile2:
    reader2 = csv.reader(csvfile2)
    # Skip the title row（if have）
    next(reader2)
    # Define the index of columns
    columns_of_interest2 = [2]  # the index begin from 0
    # Define a list
    str_array2 = []
    for row2 in reader2:
        selected_data2 = [row2[col] for col in columns_of_interest2]  # choose the columns
        # Put the item into the list
        str_array2.append(selected_data2[0])
# Change the string item of list into float
test_japan3 = [float(s) for s in str_array2]
# print(train_japan2)
#####################################END#########################################


x_max = 1 # The max dimension
x_min = 0 # The min dimension
N=30 # Number of population
D=1 # Dimension

# Generating the population
# x = np.random.rand(N, D) * (x_max - x_min) + x_min
# print(x)

  ############################# Begin LSTM model ##############################
n_preds=24
def test_LSTM_model(test_japan2,test_japan3, alpha):
    # 假设我们有一些时间序列数据
    # X_train 是输入数据，形状为 (样本数, 时间步长, 特征数)
    # y_train 是目标数据，形状为 (样本数, 输出维度)
    # 这里我们只是创建一些随机数据作为示例
    # X_train = np.random.random((100, 10, 1))  # 100个样本，每个样本10个时间步长，每个时间步长1个特征
    # y_train = np.random.random((100, 1))      # 100个样本，每个样本1个输出值
    X_train = test_japan3 
    y_train = test_japan2

    X_train = np.array(X_train)
    y_train = np.array(y_train)
    X_train= X_train.reshape(-1, 1, 1)
    y_train= y_train.reshape(-1, 1, 1)

    # 定义LSTM模型
    model = Sequential()
    model.add(LSTM(50, activation='relu', input_shape=(1, 1)))  # 输入层，50个LSTM单元
    model.add(Dense(1))  # 输出层，1个输出单元

    # 编译模型
    # learning_rate=0.001
    learning_rate=alpha
    optimizer = tf.keras.optimizers.Adam(learning_rate)
    model.compile(optimizer=optimizer, loss='mse')  # 使用Adam优化器和均方误差损失函数

    # 训练模型
    model.fit(X_train, y_train, epochs=1, batch_size=32, verbose=1)

    # 使用模型进行预测
    # X_test = np.random.random((100, 10, 1))  # 假设我们有一个测试样本

    X_test = test_japan3 

    X_test = np.array(X_test)
    X_test = X_test.reshape(-1, 1, 1)


    y_pred = model.predict(X_test)
    # print(y_pred)

    array_forecast = y_pred
    # print(array_forecast)
        # Define the dataset as python lists 
    actual   = test_japan2
    forecast = array_forecast
    # Consider a list APE to store the 
    # APE value for each of the records in dataset 
    APE = [] 
     # Iterate over the list values 
    for day in range(24): 

        # Calculate percentage error 
        per_err = (actual[day] - forecast[day]) / actual[day] 

        # Take absolute value of 
        # the percentage error (APE) 
        per_err = abs(per_err) 

        # Append it to the APE list 
        APE.append(per_err) 

    # Calculate the MAPE 
    MAPE = sum(APE)/len(APE)
    # Print the MAPE value and percentage 
    # print(f''' 
    # MAPE   : { round(MAPE, 2) } 
    # MAPE % : { round(MAPE*100, 2) } % 
    # ''')
    return MAPE , forecast
############################# End LSTM model ##############################

Plotvalue = trainvalue[1]
alpha = Plotvalue[0]
data1 = test_LSTM_model(test_japan2,test_japan3, alpha)

########################################  测试集上的数据储存 ######################################## 
testresults = data1[0]
filename = "TestResults_WOA_LSTM.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # # for row in data2:
    # #     writer.writerow(float(item) for item in row)
    # writer.writerow([float(item) for item in testresults])

    # 检查trainresults是否为可迭代对象（如数组或列表）
    if isinstance(testresults, (list, np.ndarray)):
        writer.writerow([float(item) for item in testresults])
    else:
        # 如果trainresults是单个值
        writer.writerow([float(testresults)])
########################################  测试集上的预测值数据 ######################################## 

data2 = data1[1]
filename = "WOA_LSTM.csv"
# 打开文件，并使用csv.writer写入数据
with open(filename, mode='w', newline='') as file:
    writer = csv.writer(file)
    # for row in data2:
    #     writer.writerow(float(item) for item in row)
    writer.writerow([float(item) for item in data2])

print(data2)
print(testresults)

